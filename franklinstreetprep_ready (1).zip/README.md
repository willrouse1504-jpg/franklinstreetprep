# Franklin Street Test Prep website

A responsive static website prepared for GitHub Pages.

## Deploy

1. Back up the existing repository.
2. Copy the contents of this folder into the repository root.
3. Commit and push to the default branch.
4. In GitHub, open **Settings > Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the default branch and `/ (root)`, then save.
7. In **Custom domain**, enter `www.franklinstreetprep.com` and enable HTTPS after DNS validation.

## Important content review

The user explicitly authorized placeholder information. Before publishing, verify or replace:

- Charles's surname, title, credentials, specialties, and biography.
- Will Rouse's biography and specialties.
- All service details and availability.
- Session lengths and preparation timelines in the FAQ.
- The sample testimonial. Do not publish it as a real client quote.
- The privacy notice and actual data-handling practices.

## Contact form

The form is configured for FormSubmit using `will@franklinstreetprep.com`. The first live submission may trigger a verification email. If you prefer Formspree, Netlify Forms, or a custom API, replace the form `action` in `index.html`.

## Files

- `index.html` — main website
- `assets/styles.css` — responsive design system
- `assets/script.js` — navigation, reveal effects, copyright year
- `assets/images/` — supplied headshots
- `privacy.html` — starter privacy notice
- `404.html` — custom not-found page
- `CNAME` — custom domain for GitHub Pages
- `robots.txt` and `sitemap.xml` — basic search crawling
- `site.webmanifest` — install/display metadata

## Local preview

Run `python3 -m http.server 8000` in this folder, then open `http://localhost:8000`.

## Revision included

- Removed the Approach section and its navigation link.
- Removed the sample testimonial section.
- Reduced and optimized both headshots for a more compact team layout and faster page loading.
